# Деплой

Собранная статика в `dist/`.

## Способы
1. **Netlify Drop** - https://app.netlify.com/drop (перетащи папку `dist/`)
2. **Vercel** - `npx vercel --prod` из папки `stardrop/` или `dist/`
3. **GitHub Pages** - закинь `dist/` в `docs/` или используй Actions
4. **Surge** - `npx surge dist/ stardrop.surge.sh`

Локальный превью:
```bash
npm run preview
```
